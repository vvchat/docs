package com.qiyunxin.qyxdemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;

import com.qiyunxin.qyxsdk.sdk.Constant;

/**
 * @Author: SL
 * @Date: 2017/12/26 20:25
 * @CopyRight: http://www.qiyunxin.com
 * @Parameter: TODO
 * @Function: TODO
 */
public class ResultActivity extends Activity {

    public static String Code;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        String type = getIntent().getStringExtra("type");

        if (type.equals( Constant.TYPE_PAY)) { //支付
            int errCode = getIntent().getIntExtra("err_code",0);
            String errMsg= getIntent().getStringExtra("err_msg");
            if (errCode==0) {
                Toast.makeText(this,"支付成功！",Toast.LENGTH_SHORT).show();
            }else{
                Log.i("errCode:",errCode+"");
                Log.i("errMsg:",errMsg);
                Toast.makeText(this,errMsg,Toast.LENGTH_SHORT).show();
            }
        }else if(type.equals(Constant.TYPE_THIRDLOGIN)) { //第三方登录
            String code= getIntent().getStringExtra("code");
            String state= getIntent().getStringExtra("state");
            String scope= getIntent().getStringExtra("scope");
            ResultActivity.Code = code;

            Toast.makeText(this,String.format("获取到授权CODE:%s",code),Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}
