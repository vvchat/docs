package com.qiyunxin.qyxdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    // app_id
    private static String appId = "test";
    // app key
    private static String appKey = "123456";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    protected void initView() {
        findViewById(R.id.payBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toPay();
            }
        });
        findViewById(R.id.loginBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toLogin();
            }
        });
    }

    /**
     * 企云信支付
     */
    private void toPay(){
        Intent intent = new Intent(MainActivity.this,PayActivity.class);
        intent.putExtra("app_id",appId);
        intent.putExtra("app_key",appKey);
        startActivity(intent);
    }

    /**
     * 企云信登录
     */
    private void toLogin(){
        Intent intent = new Intent(MainActivity.this,ThirdLoginActivity.class);
        intent.putExtra("app_id",appId);
        intent.putExtra("app_key",appKey);
        startActivity(intent);
//        LoginRequest loginRequest = new LoginRequest();
//        loginRequest.setAppId(appId);
//        loginRequest.setScope("snsapi_userinfo");
//        loginRequest.setState("test");
//        SDKUtils.SendRequest(loginRequest,this);
    }

}
