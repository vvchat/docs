package com.qiyunxin.qyxdemo.utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;


/**
 * @Author: SL
 * @Date: 2017/12/27 10:07
 * @CopyRight: http://www.qiyunxin.com
 * @Parameter: TODO
 * @Function: TODO
 */
public class HttpRequest {
    public static String baseUrl = "http://dev.vvchat.im";
    //统一下单
    public static String unifiedorderUrl = baseUrl + "/paybusapi/v1/pay/unifiedorder";

    // 授权token
    public static String authorizationTokenUrl = baseUrl + "/userservices/v2/authorization/token";

    // 授权用户信息
    public static String authorizationUserInfoUrl = baseUrl + "/userservices/v2/authorization/userinfo";

    private static OkHttpClient client = new OkHttpClient();
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    /**
     * post请求
     *
     * @param url
     * @param json
     * @return
     */
    public static void requestPostForJson(String url, String json, Callback callback) {
        RequestBody body = RequestBody.create(JSON, json);
        final Request request = new Request.Builder().url(url).post(body).build();
        client.newCall(request).enqueue(callback);
    }

    /**
     * get请求
     *
     * @param url
     * @param callback
     */
    public static void requestGet(String url, Headers headers, Callback callback) {
        final Request request = new Request.Builder().url(url).headers(headers).get().build();
        client.newCall(request).enqueue(callback);
    }


    /**
     * 请求统一下单接口（建议在服务端进行）
     *
     * @param model
     * @param callback
     */
    public static void requestUnifiedorder(UnifiedorderModel model, Callback callback) {

        try {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("app_id", model.getAppId());
            jsonObj.put("store_no", model.getStoreNo());
            jsonObj.put("out_trade_no", model.getOutTradeNo());
            jsonObj.put("nonce_str", model.getNonceStr());
            jsonObj.put("sign_type", model.getSignType());
            jsonObj.put("notify_url", model.getNotifyUrl());
            jsonObj.put("amount", model.getAmount());
            jsonObj.put("title", model.getTitle());
            jsonObj.put("remark", model.getRemark());
            jsonObj.put("scene_type", model.getSceneType());
            jsonObj.put("sign", model.getSign());
            requestPostForJson(unifiedorderUrl, jsonObj.toString(), callback);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * 请求获取授权token
     * @param appId appid
     * @param appKey appkey
     * @param code 授权码
     * @param callback
     */
    public static void requestAuthorizationToken(String appId, String appKey, String code, Callback callback) {
        if(appId==null) {
            appId = "";
        }
        if(appKey==null){
            appKey = "";
        }
        if (code==null) {
            code = "";
        }
        String url = String.format("%s?app_id=%s&app_key=%s&code=%s",authorizationTokenUrl,appId,appKey,code);

        requestGet(url,Headers.of(),callback);
    }

    /**
     * 获取授权用户信息
     * @param token
     * @param callback
     */
    public static void requestAuthorizationUserInfo(final String token, Callback callback) {
        Headers headers = Headers.of(new HashMap<String, String>(){{
            put("Authorization",token);
        }});
        String url = String.format("%s",authorizationUserInfoUrl);
        requestGet(url,headers,callback);
    }
}
