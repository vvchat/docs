package com.qiyunxin.qyxdemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.qiyunxin.qyxdemo.utils.HttpRequest;
import com.qiyunxin.qyxsdk.sdk.LoginRequest;
import com.qiyunxin.qyxsdk.sdk.SDKUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * @Author: SL
 * @Date: 2018/1/3 15:32
 * @CopyRight: http://www.qiyunxin.com
 * @Parameter: TODO
 * @Function: TODO
 */

/**
 * 第三方登录activity
 */
public class ThirdLoginActivity extends Activity {
    private String appId;
    private String appKey;

    public static String TOKEN;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdlogin);
        initView();
        appId = this.getIntent().getStringExtra("app_id");
        appKey = this.getIntent().getStringExtra("app_key");
    }

    protected void initView() {

        findViewById(R.id.loginBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginRequest loginRequest = new LoginRequest();
                loginRequest.setAppId(appId);
                loginRequest.setScope("snsapi_userinfo");
                loginRequest.setState("test");
                SDKUtils.SendRequest(loginRequest, ThirdLoginActivity.this);
            }
        });

        findViewById(R.id.tokenBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ResultActivity.Code != null) {
                    // 获取认证TOKEN
                    HttpRequest.requestAuthorizationToken(appId, appKey, ResultActivity.Code, new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            e.printStackTrace();
                            Toast.makeText(ThirdLoginActivity.this, String.format("获取TOKEN出错【%s】！", e.getMessage()), Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            final String result = response.body().string();
                            if (response.isSuccessful()) {
                                Log.i("result:", result);
                                try {
                                    JSONObject jsonObject = new JSONObject(result);
                                    ThirdLoginActivity.TOKEN = jsonObject.getString("token");
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(ThirdLoginActivity.this, String.format("获取到TOKEN:【%s】！", ThirdLoginActivity.TOKEN), Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            } else {
                               runOnUiThread(new Runnable() {
                                   @Override
                                   public void run() {
                                       Toast.makeText(ThirdLoginActivity.this, result, Toast.LENGTH_SHORT).show();
                                   }
                               });
                            }
                        }
                    });
                } else {
                    Toast.makeText(ThirdLoginActivity.this, "请先获取授权CODE", Toast.LENGTH_SHORT).show();
                }

            }
        });

        findViewById(R.id.userBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ThirdLoginActivity.TOKEN != null) {

                    // 获取用户信息
                    HttpRequest.requestAuthorizationUserInfo(ThirdLoginActivity.TOKEN, new Callback() {
                        @Override
                        public void onFailure(Call call, final IOException e) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(ThirdLoginActivity.this, String.format("获取用户信息出错【%s】！", e.getMessage()), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            final String result = response.body().string();
                            if (response.isSuccessful()) {
                                    Log.i("user result:",result);
                                try {
                                    final JSONObject jsonObject = new JSONObject(result);

                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                String ssex="男";
                                                int sex =jsonObject.getInt("sex");
                                                if(sex==1) {
                                                    ssex = "男";
                                                }else if (sex==0) {
                                                    ssex = "女";
                                                }
                                                Toast.makeText(ThirdLoginActivity.this, String.format("昵称：%s    性别：%s    用户ID: %s",jsonObject.getString("nickname"),ssex,jsonObject.getString("open_id")), Toast.LENGTH_SHORT).show();
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(ThirdLoginActivity.this, result, Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    });
                } else {
                    Toast.makeText(ThirdLoginActivity.this, "请先获取TOKEN", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
